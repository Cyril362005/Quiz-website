package com.cyril.quiz;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

public class AuthenticationService {
    private static final String USERS_FILE = "users.json";
    private final Map<String, String> userCredentials;
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public AuthenticationService() {
        this.userCredentials = loadUsers();
        // If the map is empty after loading, add a default user
        if (this.userCredentials.isEmpty()) {
            userCredentials.put("cyril", "123");
            saveUsers();
        }
    }

    private Map<String, String> loadUsers() {
        try (FileReader reader = new FileReader(USERS_FILE)) {
            Type type = new TypeToken<HashMap<String, String>>() {}.getType();
            Map<String, String> users = gson.fromJson(reader, type);
            return users != null ? users : new HashMap<>();
        } catch (IOException e) {
            // File not found is expected on first run, return a new empty map
            return new HashMap<>();
        }
    }

    private void saveUsers() {
        try (FileWriter writer = new FileWriter(USERS_FILE)) {
            gson.toJson(this.userCredentials, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public boolean login(String username, String password) {
        String storedPassword = userCredentials.get(username);
        return storedPassword != null && storedPassword.equals(password);
    }

    public boolean signup(String username, String password) {
        if (userCredentials.containsKey(username)) {
            return false; // Username already exists
        }
        userCredentials.put(username, password);
        saveUsers(); // Save the updated user map to the file
        return true;
    }
}