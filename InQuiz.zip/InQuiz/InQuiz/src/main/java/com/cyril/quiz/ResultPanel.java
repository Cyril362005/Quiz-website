package com.cyril.quiz;

import javax.swing.*;
import java.awt.*;

public class ResultPanel extends JPanel {
    public final JLabel scoreLabel = new JLabel();
    public final JButton retryButton = new JButton("Retry Quiz");
    public final JButton homeButton = new JButton("Back to Home");
    public final JButton leaderboardButton = new JButton("Leaderboard"); // Added button

    public ResultPanel() {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0;

        JLabel titleLabel = new JLabel("Quiz Completed!");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        gbc.gridy = 0;
        add(titleLabel, gbc);

        scoreLabel.setFont(new Font("Arial", Font.BOLD, 18));
        gbc.gridy = 1;
        add(scoreLabel, gbc);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        buttonPanel.add(retryButton);
        buttonPanel.add(homeButton);
        buttonPanel.add(leaderboardButton); // Added button
        gbc.gridy = 3;
        add(buttonPanel, gbc);
    }

    public void setScore(int score, int totalQuestions) {
        scoreLabel.setText("Your Score: " + score + " / " + totalQuestions);
    }
}