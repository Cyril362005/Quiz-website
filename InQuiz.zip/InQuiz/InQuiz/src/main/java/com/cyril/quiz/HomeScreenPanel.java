package com.cyril.quiz;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;

public class HomeScreenPanel extends JPanel {
    public final JComboBox<String> topicComboBox = new JComboBox<>();
    public final JButton startQuizButton = new JButton("Start Quiz");
    public final JButton historyButton = new JButton("View History");
    public final JButton toggleThemeButton = new JButton("Toggle Theme");

    public HomeScreenPanel() {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0;

        // --- Title ---
        gbc.gridy = 0;
        JLabel titleLabel = new JLabel("<html>Welcome to <font color='#2864DC'>InQuiz</font>!</html>");
        titleLabel.setFont(new Font("Segoe UI Light", Font.BOLD, 32));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(titleLabel, gbc);

        // --- Topic Dropdown ---
        gbc.gridy = 1;
        topicComboBox.setBorder(BorderFactory.createTitledBorder("Choose a Topic"));
        topicComboBox.setPreferredSize(new Dimension(250, 50));
        add(topicComboBox, gbc);

        // --- Start Quiz Button (Primary Action) ---
        gbc.gridy = 2;
        startQuizButton.setFont(new Font("Segoe UI", Font.BOLD, 16));
        startQuizButton.setBackground(Color.BLACK);
        startQuizButton.setForeground(Color.WHITE);
        startQuizButton.setPreferredSize(new Dimension(250, 45));
        add(startQuizButton, gbc);

        // Add the hover animation for the primary button
        startQuizButton.addMouseListener(new java.awt.event.MouseAdapter() {
            // Store the original border to restore it later
            Border originalBorder = startQuizButton.getBorder();

            public void mouseEntered(java.awt.event.MouseEvent evt) {
                // On hover, create a new slightly thicker border to "lift" the button
                // This creates a subtle visual feedback effect
                startQuizButton.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(Color.GRAY, 1),
                        BorderFactory.createEmptyBorder(4, 4, 4, 4)
                ));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                // When the mouse leaves, restore the original border
                startQuizButton.setBorder(originalBorder);
            }
        });


        // --- Secondary Buttons in a separate panel ---
        gbc.gridy = 3;
        JPanel secondaryButtonPanel = new JPanel(new GridLayout(1, 2, 10, 10));

        // Style secondary buttons to use the default theme look but remain rounded
        historyButton.putClientProperty("JButton.buttonType", "roundRect");
        toggleThemeButton.putClientProperty("JButton.buttonType", "roundRect");

        secondaryButtonPanel.add(historyButton);
        secondaryButtonPanel.add(toggleThemeButton);
        add(secondaryButtonPanel, gbc);
    }
}