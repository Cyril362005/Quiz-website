package com.cyril.quiz;

import com.formdev.flatlaf.FlatDarkLaf;
import com.formdev.flatlaf.FlatLightLaf;
import javax.swing.*;
import java.awt.Color;
import java.awt.Font;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class ThemeService {
    private static final String SETTINGS_FILE = "settings.properties";
    private boolean isDarkMode = false;

    public void initializeTheme() {
        // Apply custom styling properties
        UIManager.put("defaultFont", new Font("Segoe UI Light", Font.PLAIN, 15));
        UIManager.put("Component.focusColor", new Color(40, 100, 220));
        UIManager.put("Component.focusWidth", 1);
        UIManager.put("Component.innerFocusWidth", 0);
        UIManager.put("Component.arc", 15);
        UIManager.put("Button.arc", 999); // Use a large value for pill-shaped buttons

        // Load the saved theme preference
        this.isDarkMode = loadThemePreference();
        applyTheme();
    }

    public void toggleTheme(JFrame mainFrame) {
        isDarkMode = !isDarkMode;
        applyTheme();
        SwingUtilities.updateComponentTreeUI(mainFrame);
        saveThemePreference();
    }

    private void applyTheme() {
        try {
            if (isDarkMode) {
                UIManager.setLookAndFeel(new FlatDarkLaf());
            } else {
                UIManager.setLookAndFeel(new FlatLightLaf());
            }
        } catch (UnsupportedLookAndFeelException e) {
            System.err.println("Failed to set Look and Feel.");
        }
    }

    private void saveThemePreference() {
        Properties props = new Properties();
        props.setProperty("theme", isDarkMode ? "dark" : "light");
        try (FileOutputStream out = new FileOutputStream(SETTINGS_FILE)) {
            props.store(out, "Application Settings");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private boolean loadThemePreference() {
        Properties props = new Properties();
        try (FileInputStream in = new FileInputStream(SETTINGS_FILE)) {
            props.load(in);
            return "dark".equals(props.getProperty("theme", "light"));
        } catch (IOException e) {
            // Settings file doesn't exist yet, default to light mode
            return false;
        }
    }
}