package com.cyril.quiz;

import javax.swing.*;
import java.awt.*;

/**
 * The main window of the application.
 * It uses a CardLayout to switch between different screens (panels).
 */
public class MainFrame extends JFrame {
    private final CardLayout cardLayout = new CardLayout();
    private final JPanel mainPanel = new JPanel(cardLayout);

    public MainFrame() {
        setTitle("Java Swing Quiz Application");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null); // Center the window

        add(mainPanel);
    }

    /**
     * Adds a screen (panel) to the main card layout.
     * @param panel The panel to add.
     * @param name The name to identify the panel.
     */
    public void addScreen(JPanel panel, String name) {
        mainPanel.add(panel, name);
    }

    /**
     * Shows a specific screen by its name.
     * @param name The name of the panel to show.
     */
    public void showScreen(String name) {
        cardLayout.show(mainPanel, name);
    }
}