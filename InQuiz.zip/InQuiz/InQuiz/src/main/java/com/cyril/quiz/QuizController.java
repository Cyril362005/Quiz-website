package com.cyril.quiz;

import javax.swing.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class QuizController {
    // Services
    private final AuthenticationService authService;
    private final APIClient apiClient;
    private final HistoryService historyService;
    private final ThemeService themeService;

    // UI Components
    private final MainFrame mainFrame;
    private final LoginPanel loginPanel;
    private final SignupPanel signupPanel;
    private final HomeScreenPanel homeScreenPanel;
    private final QuestionPanel questionPanel;
    private final ResultPanel resultPanel;
    private final HistoryPanel historyPanel;
    private final LeaderboardPanel leaderboardPanel;

    // Quiz State
    private List<QuestionModel> questions;
    private int currentQuestionIndex;
    private int score;
    private String currentTopic;
    private String currentUsername;
    private Timer timer;
    private int timeLeft;
    private List<Integer> userAnswers;

    public QuizController(AuthenticationService authService, APIClient apiClient, HistoryService historyService, ThemeService themeService, MainFrame mainFrame, LoginPanel loginPanel, SignupPanel signupPanel, HomeScreenPanel homeScreenPanel, QuestionPanel questionPanel, ResultPanel resultPanel, HistoryPanel historyPanel, LeaderboardPanel leaderboardPanel) {
        this.authService = authService;
        this.apiClient = apiClient;
        this.historyService = historyService;
        this.themeService = themeService;
        this.mainFrame = mainFrame;
        this.loginPanel = loginPanel;
        this.signupPanel = signupPanel;
        this.homeScreenPanel = homeScreenPanel;
        this.questionPanel = questionPanel;
        this.resultPanel = resultPanel;
        this.historyPanel = historyPanel;
        this.leaderboardPanel = leaderboardPanel;
        this.timer = new Timer(1000, e -> updateTimer());
        attachListeners();
    }

    private void attachListeners() {
        loginPanel.loginButton.addActionListener(e -> handleLogin());
        loginPanel.signupButton.addActionListener(e -> mainFrame.showScreen("SIGNUP"));
        signupPanel.signupButton.addActionListener(e -> handleSignup());
        signupPanel.backToLoginButton.addActionListener(e -> mainFrame.showScreen("LOGIN"));
        homeScreenPanel.startQuizButton.addActionListener(e -> startQuiz());
        homeScreenPanel.historyButton.addActionListener(e -> showHistory());
        homeScreenPanel.toggleThemeButton.addActionListener(e -> themeService.toggleTheme(mainFrame));
        questionPanel.previousButton.addActionListener(e -> handlePreviousQuestion());
        questionPanel.nextButton.addActionListener(e -> handleNextQuestion());
        resultPanel.retryButton.addActionListener(e -> startQuiz());
        resultPanel.homeButton.addActionListener(e -> showHomeScreen());
        resultPanel.leaderboardButton.addActionListener(e -> showLeaderboard());
        historyPanel.backButton.addActionListener(e -> showHomeScreen());
        leaderboardPanel.backButton.addActionListener(e -> showHomeScreen());
    }

    private void handleNextQuestion() {
        timer.stop();
        userAnswers.set(currentQuestionIndex, questionPanel.getSelectedOption());

        // Check the answer and play a sound
        if (questionPanel.getSelectedOption() == questions.get(currentQuestionIndex).getAnswerIndex()) {
            playSound("sounds/correct.wav"); // Play correct sound
        } else {
            playSound("sounds/wrong.wav"); // Play wrong sound
        }

        if (currentQuestionIndex < questions.size() - 1) {
            currentQuestionIndex++;
            loadQuestion();
        } else {
            calculateAndShowResults();
        }
    }

    private void calculateAndShowResults() {
        score = 0;
        for (int i = 0; i < questions.size(); i++) {
            if (userAnswers.get(i) == questions.get(i).getAnswerIndex()) {
                score++;
            }
        }
        animateAndShowResults();
    }

    private void animateAndShowResults() {
        resultPanel.setScore(0, questions.size());
        mainFrame.showScreen("RESULTS");

        Timer animationTimer = new Timer(50, null);
        animationTimer.addActionListener(e -> {
            String[] parts = resultPanel.scoreLabel.getText().split(" ");
            int currentDisplayScore = Integer.parseInt(parts[2]);
            if (currentDisplayScore < score) {
                resultPanel.setScore(currentDisplayScore + 1, questions.size());
            } else {
                animationTimer.stop();
            }
        });
        animationTimer.start();

        String date = new SimpleDateFormat("yyyy-MM-dd HH:mm").format(new Date());
        HistoryEntry entry = new HistoryEntry(date, currentTopic, score, this.currentUsername);
        historyService.addEntry(entry);
    }

    private void playSound(String soundFilePath) {
        try {
            java.net.URL url = this.getClass().getResource("/" + soundFilePath);
            if (url != null) {
                java.applet.AudioClip clip = java.applet.Applet.newAudioClip(url);
                clip.play();
            } else {
                System.err.println("Couldn't find file: " + soundFilePath);
            }
        } catch (Exception e) {
            System.err.println("Error playing sound: " + e.getMessage());
        }
    }

    // --- All other methods remain the same ---
    private void startQuiz() {
        currentTopic = (String) homeScreenPanel.topicComboBox.getSelectedItem();
        if (currentTopic == null) return;
        try {
            questions = apiClient.getQuestions(currentTopic);
        } catch (ApiException e) {
            JOptionPane.showMessageDialog(mainFrame, "Could not fetch live questions. Loading fallback.", "API Error", JOptionPane.WARNING_MESSAGE);
            questions = loadFallbackQuestions();
        }
        currentQuestionIndex = 0;
        score = 0;
        userAnswers = new ArrayList<>(Collections.nCopies(questions.size(), -1));
        if (questions != null && !questions.isEmpty()) {
            loadQuestion();
            mainFrame.showScreen("QUIZ");
        }
    }
    private void loadQuestion() {
        questionPanel.progressLabel.setText("Question " + (currentQuestionIndex + 1) + " of " + questions.size());
        int selectedAnswer = userAnswers.get(currentQuestionIndex);
        questionPanel.displayQuestion(questions.get(currentQuestionIndex), selectedAnswer);
        questionPanel.previousButton.setEnabled(currentQuestionIndex > 0);
        questionPanel.nextButton.setText(currentQuestionIndex == questions.size() - 1 ? "Finish" : "Next");
        resetTimer();
    }
    private void handlePreviousQuestion() {
        timer.stop();
        userAnswers.set(currentQuestionIndex, questionPanel.getSelectedOption());
        if (currentQuestionIndex > 0) {
            currentQuestionIndex--;
            loadQuestion();
        }
    }
    private void showHistory() {
        List<HistoryEntry> history = historyService.readHistory();
        historyPanel.setHistoryData(history);
        mainFrame.showScreen("HISTORY");
    }
    private void showLeaderboard() {
        List<HistoryEntry> leaderboard = historyService.getLeaderboard();
        leaderboardPanel.setLeaderboardData(leaderboard);
        mainFrame.showScreen("LEADERBOARD");
    }
    private List<QuestionModel> loadFallbackQuestions() {
        List<QuestionModel> fallback = new ArrayList<>();
        fallback.add(new QuestionModel("What is a fallback question?", List.of("A", "B", "C", "D"), 0));
        return fallback;
    }
    private void resetTimer() {
        timeLeft = 15;
        questionPanel.timerLabel.setText("Time: " + timeLeft + "s");
        timer.restart();
    }
    private void updateTimer() {
        timeLeft--;
        questionPanel.timerLabel.setText("Time: " + timeLeft + "s");
        if (timeLeft <= 0) {
            handleNextQuestion();
        }
    }
    private void handleLogin() {
        String username = loginPanel.userField.getText();
        String password = new String(loginPanel.passField.getPassword());
        if (authService.login(username, password)) {
            this.currentUsername = username;
            showHomeScreen();
        } else {
            JOptionPane.showMessageDialog(mainFrame, "Invalid username or password.", "Login Failed", JOptionPane.ERROR_MESSAGE);
        }
    }
    private void handleSignup() {
        String username = signupPanel.userField.getText();
        String password = new String(signupPanel.passField.getPassword());
        String confirmPassword = new String(signupPanel.confirmPassField.getPassword());
        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(mainFrame, "Username and password cannot be empty.", "Signup Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!password.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(mainFrame, "Passwords do not match.", "Signup Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (authService.signup(username, password)) {
            JOptionPane.showMessageDialog(mainFrame, "Signup successful! Please log in.", "Success", JOptionPane.INFORMATION_MESSAGE);
            mainFrame.showScreen("LOGIN");
        } else {
            JOptionPane.showMessageDialog(mainFrame, "Username already exists.", "Signup Failed", JOptionPane.ERROR_MESSAGE);
        }
    }
    private void showHomeScreen() {
        List<String> topics = apiClient.getTopics();
        homeScreenPanel.topicComboBox.removeAllItems();
        for (String topic : topics) {
            homeScreenPanel.topicComboBox.addItem(topic);
        }
        mainFrame.showScreen("HOME");
    }
}