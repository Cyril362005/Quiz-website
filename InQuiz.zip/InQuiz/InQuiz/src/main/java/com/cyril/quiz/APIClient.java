package com.cyril.quiz;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.commons.text.StringEscapeUtils;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class APIClient {
    private final HttpClient httpClient = HttpClient.newHttpClient();
    private final Gson gson = new GsonBuilder().create();

    public List<String> getTopics() {
        return Arrays.asList("Computers", "Gadgets", "General Knowledge");
    }

    // Add "throws ApiException" to the method signature here
    public List<QuestionModel> getQuestions(String topic) throws ApiException {
        int categoryId = 18; // Default to "Science: Computers"
        if (topic.equals("Gadgets")) {
            categoryId = 30;
        } else if (topic.equals("General Knowledge")) {
            categoryId = 9;
        }

        String apiUrl = "https://opentdb.com/api.php?amount=10&category=" + categoryId + "&type=multiple";
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(apiUrl))
                .build();

        try {
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            TriviaAPIResponse apiResponse = gson.fromJson(response.body(), TriviaAPIResponse.class);

            if (apiResponse != null && apiResponse.results != null) {
                return mapToQuestionModels(apiResponse.results);
            } else {
                throw new ApiException("Failed to parse API response.", null);
            }
        } catch (Exception e) {
            // Wrap and throw the custom exception
            throw new ApiException("Could not fetch questions from API.", e);
        }
    }

    private List<QuestionModel> mapToQuestionModels(List<TriviaQuestion> triviaQuestions) {
        List<QuestionModel> questionModels = new ArrayList<>();
        for (TriviaQuestion tq : triviaQuestions) {
            List<String> options = new ArrayList<>(tq.incorrect_answers);
            options.add(tq.correct_answer);
            Collections.shuffle(options);
            int answerIndex = options.indexOf(tq.correct_answer);
            String decodedQuestion = StringEscapeUtils.unescapeHtml4(tq.question);
            List<String> decodedOptions = new ArrayList<>();
            for (String option : options) {
                decodedOptions.add(StringEscapeUtils.unescapeHtml4(option));
            }
            QuestionModel qm = new QuestionModel(decodedQuestion, decodedOptions, answerIndex);
            questionModels.add(qm);
        }
        return questionModels;
    }
}