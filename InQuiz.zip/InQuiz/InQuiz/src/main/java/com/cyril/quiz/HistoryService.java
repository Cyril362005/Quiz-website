package com.cyril.quiz;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class HistoryService {
    private static final String HISTORY_FILE = "history.json";
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public List<HistoryEntry> readHistory() {
        try (FileReader reader = new FileReader(HISTORY_FILE)) {
            Type listType = new TypeToken<ArrayList<HistoryEntry>>() {}.getType();
            List<HistoryEntry> history = gson.fromJson(reader, listType);
            return history != null ? history : new ArrayList<>();
        } catch (IOException e) {
            // File not found is expected on first run, return empty list
            return new ArrayList<>();
        }
    }

    public void addEntry(HistoryEntry newEntry) {
        List<HistoryEntry> history = readHistory();
        history.add(0, newEntry); // Add new entry to the top of the list
        try (FileWriter writer = new FileWriter(HISTORY_FILE)) {
            gson.toJson(history, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    // In HistoryService.java, add this new method:
    public List<HistoryEntry> getLeaderboard() {
        List<HistoryEntry> history = readHistory();
        // Sort the list by score in descending order
        history.sort((e1, e2) -> Integer.compare(e2.getScore(), e1.getScore()));
        return history;
    }
}